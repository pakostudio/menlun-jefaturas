-- MENLUN NEXUS · Sprint 2
-- Flujo operativo: Pedido → factura → almacén → logística → evidencia → cierre

create schema if not exists menlun;

create table if not exists menlun.flujo_pedidos (
  id uuid primary key default gen_random_uuid(),
  folio text not null,
  cliente text not null,
  etapa_actual text not null default 'pedido_recibido' check (
    etapa_actual in (
      'pedido_recibido',
      'factura_solicitada',
      'factura_emitida',
      'almacen_surtido',
      'logistica_programada',
      'en_ruta',
      'evidencia_cargada',
      'cerrado'
    )
  ),
  responsable_actual text not null,
  fecha_compromiso date,
  bloqueado boolean not null default false,
  motivo_bloqueo text,
  comentario text,
  evidencia_url text,
  creado_por text,
  creado_en timestamptz not null default now(),
  actualizado_en timestamptz not null default now(),
  cerrado_en timestamptz
);

create index if not exists idx_flujo_pedidos_etapa on menlun.flujo_pedidos(etapa_actual);
create index if not exists idx_flujo_pedidos_fecha on menlun.flujo_pedidos(fecha_compromiso);
create index if not exists idx_flujo_pedidos_actualizado on menlun.flujo_pedidos(actualizado_en desc);

alter table menlun.flujo_pedidos disable row level security;

grant usage on schema menlun to anon, authenticated;
grant all on menlun.flujo_pedidos to anon, authenticated;

notify pgrst, 'reload schema';
